export interface Book {
  title: string;
}
