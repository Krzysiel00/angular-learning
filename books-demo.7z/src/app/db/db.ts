import {Book} from '../models/book';

export const books: Array<Book> = [
  {
    title: 'Janko muzykant',
  },
  {
    title: 'Krew Elfów',
  },
  {
    title: 'Chłopi',
  },
];
