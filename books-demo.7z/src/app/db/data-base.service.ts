import { Injectable } from '@angular/core';
import {Book} from '../models/book';
import {BehaviorSubject, Observable} from 'rxjs';
import {books} from './db';

@Injectable({
  providedIn: 'root'
})
export class DataBaseService {
  private database: BehaviorSubject<Book[]> = new BehaviorSubject<Book[]>([]);

  constructor() {
    this.database.next(books);
  }

  getBooks(): Observable<Book[]> {
    return this.database.asObservable();
  }

}
